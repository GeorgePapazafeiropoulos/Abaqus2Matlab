% %% SCRIPT FILE TO FIT A COHESIVE LAW
% If using this code for research or industrial purposes, please cite:
% G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
% Abaqus2Matlab: a suitable tool for finite element post-processing.
% Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
% DOI:10.1016/j.advengsoft.2017.01.006

% This code is written by M. Muniz-Calvente, E. Martinez-Paneda
% miguelmunizcalvente@gmail.com
clear
clc
close all
S = mfilename('fullpath');
f = filesep;
ind=strfind(S,f);
S1=S(1:ind(end)-1);
cd(S1)

%% STEP 1: read experimental CMOD and LOAD from excel file
[CMOD_exp,F_exp] = import_exp_data('Exp_data.xlsx','Data',4);
figure(1)
hold on
plot(CMOD_exp,F_exp)
xlabel 'CMOD [mm]'
ylabel 'P[N]'
grid on
savefig('Experimental_values.fig')


%% STEP 2: define initial points to train the neural net
ENERGY_points=[10,10,150,150,80]';
MAXS_points=[100,250,250,100,175]';
INPUT_VALUES=[ENERGY_points,MAXS_points];

figure(2)
hold on
plot(INPUT_VALUES(:,1),INPUT_VALUES(:,2),'kx')
xlabel 'ENERGY'
ylabel 'MAXS'
grid on
savefig('Initial_values.fig')

%% STEP 3: Simulate the LOAD-CMOD for each initial point
Inp_file='Input_file.inp';
for sim=1:length(MAXS_points) % Repeat this bucle for each initial point of MAXS and ENERGY   
    % Create a .inp file with the cohesive parameters defined by MAXS_points
    % and ENERGY_points variables
    Exit_file_name=Create_new_input(Inp_file,MAXS_points(sim),ENERGY_points(sim));
        
    % Run the input file with Abaqus
    system(['abaqus job=' Exit_file_name]);
    disp(['FEM simulation: ' Exit_file_name ' RUNNING']);
    % Pause Matlab execution to give Abaqus enough time to create the lck file
    pause(10)

    % If the lck file exists then halt Matlab execution
    while exist([Exit_file_name '.lck'],'file')==2
      pause(0.1)
    end
    disp(['FEM simulation: ' Exit_file_name ' FINISHED']);
    
    % Postprocess Abaqus results file with Abaqus2Matlab functions
    % Obtain the desired output data
    clear out
    out = readFil([Exit_file_name '.fil'],[101,104]);
    % CMOD
    CMOD_simulated{sim}=2*out{1,1}(4:end,3);
    % Reaction force
    F_simulated{sim}=out{1,2}(4:end,3);

end

%% STEP 4: Obtain the key points of the  LOAD-CMOD curves to be fitted by the neural network
num_points=12;
CMOD_points=linspace(max(min(cell2mat(CMOD_simulated))),min(max((CMOD_exp))),num_points);
F_exp_points=interp1(CMOD_exp,F_exp,CMOD_points);

% plot the experimental points to be fitted
figure(1)
hold on
plot(CMOD_points,F_exp_points,'ob')
savefig('Experimental_values_Discretized.fig')

% Obtain the key points of the  simulated LOAD-CMOD curves to be fitted by the neural network
for sim=1:length(MAXS_points)
    F_simulated_key_points(sim,:)= interp1(CMOD_simulated{sim},F_simulated{sim},CMOD_points);
end

% plot the simulated points to be used by the Neural Net
for sim=1:length(MAXS_points)
    plot(CMOD_simulated{sim},F_simulated{sim})
    plot(CMOD_points,F_simulated_key_points(sim,:),'ro')
end
savefig('Initial_LOAD_CMOD_Curves.fig')

save('DATA_INITIAL.mat') %Optional save data before to start the iterativ procces


%% STEP 5: Iterative Process to obtain the optimal cohesive values
% define initial point to search for a minimun error
x0_(sim,:)=[80,175]; % start point for the minimization process (central point) 
error(sim)=1;

while error(sim)>1e-5


%% STEP 5.1: Obtain the neuronal net

% Choose a Training Function
    trainFcn = 'trainbr';  % Bayesian Regularization

% Create a Fitting Network
    hiddenLayerSize = 10;
    net = fitnet(hiddenLayerSize,trainFcn);

% Setup Division of Data for Training, Validation, Testing
    net.divideParam.trainRatio = 80/100;
    net.divideParam.valRatio = 15/100;
    net.divideParam.testRatio = 5/100;

% Train the Network
    [net,tr] = train(net,INPUT_VALUES',F_simulated_key_points');

% Test the Network
    y = net(INPUT_VALUES');
    e = gsubtract(F_simulated_key_points',y);
    performance = perform(net,F_simulated_key_points',y);


%% STEP 5.2: Obtain the optimal values of MAXS and ENERGY to fit the experimental curve.
    funt=@(GT) sum((net([GT(1);GT(2)])-F_exp_points').^2)/sum(F_exp_points.^2); %function to be optimized
    [Optimal_values,~]=fminsearch(funt,x0_(sim,:)); %optimization process

    sim=sim+1;
    ENERGY_optimal(sim)=Optimal_values(1);
    MAXS_Optimal(sim)=Optimal_values(2);
    x0_(sim,:)=[ENERGY_optimal(sim),MAXS_Optimal(sim)];%actualized the starting point of fminsearch function


%% STEP 5.3: Used the optimal values of MAXS and ENERGY to obtain a new Load-CMOD curve by Abaqus.
    % Create a .inp file with the cohesive parameters defined by MAXS_points
    % and ENERGY_points variables
    [ Exit_file_name ] = Create_new_input( Inp_file,MAXS_Optimal(sim),ENERGY_optimal(sim) );
    disp(['FEM simulation: ' Exit_file_name ' RUNNING']);

    % Run the input file with Abaqus (eliminate the .inp(extension))
    system(['abaqus job=' Exit_file_name]);
    % Pause Matlab execution to give Abaqus enough time to create the lck file
    pause(10)
    %%
    % If the lck file exists then halt Matlab execution
    while exist([Exit_file_name '.lck'],'file')==2
      pause(10)
    end
    disp(['FEM simulation: ' Exit_file_name ' FINISHED']);

    %% Postprocess Abaqus results file with Matlab
    % Obtain the desired output data
    clear out
    out = readFil([Exit_file_name '.fil'],[101,104]);
    % CMOD
    CMOD_simulated{sim}=2*out{1,1}(:,3);
    % Reaction force
    F_simulated{sim}=out{1,2}(:,3);
    
    % Obtain the key points of the  simulated LOAD-CMOD curves to be fitted by the neural network
    F_simulated_key_points(sim,:)=interp1(CMOD_simulated{sim}(4:end),F_simulated{sim}(4:end),CMOD_points);

    % Obtain the error between the experimental and FEM curves
    error(sim)=sum((F_simulated_key_points(sim,:)-F_exp_points).^2)/sum(F_exp_points.^2);
    
    %% actualized the input values of the neural network by adding the last optimal points obtained
    INPUT_VALUES(sim,:)=[ENERGY_optimal(sim),MAXS_Optimal(sim)];

    %% Check the variation in the MAXS and ENERGY values obtained from one iteration to another.
    var1(sim)=abs(INPUT_VALUES(sim,1)-INPUT_VALUES(sim-1,1))/((INPUT_VALUES(sim,1)+INPUT_VALUES(sim-1,1))/2);
    var2(sim)=abs(INPUT_VALUES(sim,2)-INPUT_VALUES(sim-1,2))/((INPUT_VALUES(sim,2)+INPUT_VALUES(sim-1,2))/2);
    %% If there is not significant variation, the process is stoped.
    if var1(sim)<0.01 && var2(sim)<0.01
        break
    end
end

%% STEP 6: Plot final results

% Plot comparison between CMOD-loads curves
figure(4)
hold on
plot(CMOD_exp,F_exp)
plot(CMOD_simulated{sim},F_simulated{sim}) 
xlabel 'CMOD [mm]'
ylabel 'P[N]'
legend ('Experimental','FEM')
grid on
savefig('CMOD_LOAD_Final_solution.fig')

% Plot optimal MAXs and ENERGY obtained points at each iteration
figure(5)
hold on
plot(INPUT_VALUES(1:5,1),INPUT_VALUES(1:5,2),'kx')
plot(INPUT_VALUES(6:end,1),INPUT_VALUES(6:end,2),'r*--')
grid on
xlabel 'ENERGY'
ylabel 'MAXS'
savefig('Optimal_points_obtained_for_each_iteration.fig')


