function Exit_file_name = Create_new_input(File_name,MAXS,ENERGY)

% If using this function for research or industrial purposes, please cite:
% G. Papazafeiropoulos, M. Muiz-Calvente, E. Martnez-Paeda. 
% Abaqus2Matlab: a novel tool for finite element post-processing (submitted)

fid = fopen(File_name,'r');
file=textscan(fid,'%s','Delimiter','\n');
flines=(file{1});
lif=length(flines); 
fclose(fid);
fid = fopen(File_name,'r');
Exit_file_name=strcat(File_name(1:(end-4)),'_MAXS_',num2str(floor(MAXS)),'_ENERGY_',num2str(floor(ENERGY)));

Salida = fopen([Exit_file_name '.inp' ],'w');


for i=1:lif
    tline = fgetl(fid); 
    tline=strrep(tline,'<MAXS>',num2str(MAXS));
    tline=strrep(tline,'<ENERGY>',num2str(ENERGY));    
    fprintf(Salida,'%s \r\n',tline);
end
fclose('all');


end

