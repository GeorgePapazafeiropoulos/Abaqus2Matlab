%% Documentation
% This guide is a reference to using mtx2Matlab v.3.0, which is an integral
% component of Abaqus2Matlab. It contains instructions for usage of the
% various routines involved when using mtx2Matlab.

%% getMatrix.m
% Help section of the function getMatrix.m
help getMatrix

%% mtxScan.m
% Help section of the function mtxScan.m
help mtxScan

%% mtx2sparse.m
% Help section of the function mtx2sparse.m
help mtx2sparse

%%
%  _________________________________________________________________________
%  Abaqus2Matlab - www.abaqus2matlab.com
%  Copyright (c) 2017-2020 by George Papazafeiropoulos
%
%  If using this toolbox for research or industrial purposes, please cite:
%  G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
%  Abaqus2Matlab: a suitable tool for finite element post-processing.
%  Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
%  DOI:10.1016/j.advengsoft.2017.01.006

