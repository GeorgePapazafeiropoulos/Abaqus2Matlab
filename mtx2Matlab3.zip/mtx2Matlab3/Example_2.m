%% Example_2
% An Abaqus model is developed in terms of the Abaqus input file
% *example.inp*. The input file *example.inp* is provided along with other
% necessary files with this example. The input file *example.inp* must be
% run in Abaqus before running the current script. The model is comprised
% of a 3D beam model discretized in C3D8 elements with a solid section
% associated with a linear elastic material. Along the cross section at the
% one end of the beam a general tangential surface traction is applied
% which is equivalent to a force perpendicular to the beam axis, whereas
% boundary condition of total fixity is applied at the other end of the
% beam. There are 8 steps in the Abaqus input file as follows:
%
% # Static analysis of the beam with the applied load and boundary
% conditions.
% # Frequency analysis of the beam without the applied traction
% # Generation of the global stiffness, mass and load matrices in the
% matrix input format
% # Generation of the global stiffness, mass and load matrices in the
% coordinate format
% # Generation of the global stiffness, mass and load matrices in the
% labels format
% # Generation of the local element stiffness, mass and load matrices in
% the matrix input format
% # Generation of the local element stiffness, mass and load matrices in
% the coordinate format
% # Generation of the local element stiffness, mass and load matrices in
% the labels format
%
% In this example the stiffness and mass matrices of the Abaqus model are
% loaded using *mtx2Matlab* and then used for solving the eigenvalue
% problem in order to find the eigenfrequencies of the Abaqus model in
% Matlab, independently, without running an Abaqus frequency analysis. The
% results of this solution are then compared with the results of the Abaqus
% frequency analysis specified at the step 2 above, in terms of the
% eigenfrequencies and eigenmodes. The corresponding results of the two
% frequency analyses are shown to be identical.
%
% For more information about this example and *mtx2Matlab* in general,
% please check <http://www.mathworks.com this post> at the *Abaqus2Matlab*
% <http://www.abaqus2matlab.com/ Website>
%

%% Frequency analysis in terms of _matrix input_ or _labels_ format
% Degrees of freedom per node of the solid beam model
dofsPerNode=3;

%%
% Obtain the global stiffness and mass matrices using Abaqus2Matlab
[KMAT1,Kout1] = getMatrix('example_STIF3.mtx','matrix',...
    'matrix input','global',dofsPerNode);
K = KMAT1{1};
[MMAT1,Mout1] = getMatrix('example_MASS3.mtx','matrix',...
    'matrix input','global',dofsPerNode);
M = MMAT1{1};

%%
% Problem size
n=size(K,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag = spdiags(K,0);

%%
% Find fixed degrees of freedom
Bfixed=find(Kdiag>9e35);

%%
% Find free degrees of freedom
Bfree=setdiff((1:numel(Kdiag))',Bfixed);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Ksymm = K+K'-spdiags(Kdiag,0,n,n);

%%
% Take the free-free segment of the stiffness matrix
Kff=Ksymm(Bfree,Bfree);

%%
% Take the free-free segment of the mass matrix
Mff=M(Bfree,Bfree);

%%
% Solve eigenfrequency equation (frequency analysis)
Kff=full(Kff);
Mff=full(Mff);
[Vf,Df]=eig(Kff,Mff);

%%
% Calculate the eigenfrequencies which are lower than 100 Hz
f=sqrt(diag(Df))/(2*pi);
f=f(f<100)

%% Frequency analysis in terms of _coordinate_ format
% Obtain the global stiffness and mass matrices using Abaqus2Matlab
[KMAT2,Kout2] = getMatrix('example_STIF4.mtx','matrix',...
    'coordinate','global',dofsPerNode);
K = KMAT2{1};
[MMAT2,Mout2] = getMatrix('example_MASS4.mtx','matrix',...
    'coordinate','global',dofsPerNode);
M = MMAT2{1};

%%
% Problem size
n=size(K,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag = spdiags(K,0);

%%
% Find fixed degrees of freedom
Bfixed=find(Kdiag>9e35);

%%
% Find free degrees of freedom
Bfree=setdiff((1:numel(Kdiag))',Bfixed);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Ksymm = K;

%%
% Take the free-free segment of the stiffness matrix
Kff=Ksymm(Bfree,Bfree);

%%
% Take the free-free segment of the mass matrix
Mff=M(Bfree,Bfree);

%%
% Solve eigenfrequency equation (frequency analysis)
Kff=full(Kff);
Mff=full(Mff);
[Vf,Df]=eig(Kff,Mff);

%%
% Calculate the eigenfrequencies which are lower than 100 Hz
f=sqrt(diag(Df))/(2*pi);
f=f(f<100)

%% Abaqus frequency analysis results
% By comparing the frequency (cycles/time) of each printscreen of Abaqus to
% the eigenfrequencies that are calculated by Matlab, it is shown that the
% results are identical.

%% 
% Mode 1
% 
% <<Mode1.png>>
% 

%%
% Mode 2
% 
% <<Mode2.png>>
% 

%%
% Mode 3
% 
% <<Mode3.png>>
% 

%%
% Mode 4
% 
% <<Mode4.png>>
% 

%%
% Mode 5
% 
% <<Mode5.png>>
% 

%%
% Mode 6
% 
% <<Mode6.png>>
% 

%%
% Mode 7
% 
% <<Mode7.png>>
% 

%%
% Mode 8
% 
% <<Mode8.png>>
% 

%%
% Mode 9
% 
% <<Mode9.png>>
% 

%%
%  _________________________________________________________________________
%  Abaqus2Matlab - www.abaqus2matlab.com
%  Copyright (c) 2017-2020 by George Papazafeiropoulos
%
%  If using this toolbox for research or industrial purposes, please cite:
%  G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
%  Abaqus2Matlab: a suitable tool for finite element post-processing.
%  Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
%  DOI:10.1016/j.advengsoft.2017.01.006


