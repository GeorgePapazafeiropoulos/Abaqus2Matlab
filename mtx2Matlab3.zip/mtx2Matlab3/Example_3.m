%% Example_3
% An Abaqus model is developed in terms of the Abaqus input file
% *TrussFEModel.inp*. The input file *TrussFEModel.inp* is provided along
% with other necessary files. The input file *TrussFEModel.inp* must be run
% in Abaqus before running the current script. The model is comprised of a
% 2D truss model discretized in T2D2 elements with a solid section
% associated with a linear elastic material. There are 3 steps in the
% Abaqus input file as follows:
%
% # Static analysis of the truss with the applied load and boundary
% conditions.
% # Generation of the global stiffness matrix in the matrix input format
% # Generation of the local element stiffness matrices in the matrix input
% format
%
% In this example the stiffness matrices of the initial truss model (called
% as element-based truss model, *trussFEModel.inp*) are loaded using
% *mtx2Matlab*. Afterwards, the local element stiffness matrix of the
% element 17 is subtracted from the global stiffness matrix and then the
% input file of an equivalent Abaqus model is created (called as
% matrix-based truss model, *trussMatrixModel.inp*), which is formulated in
% terms of one element (17) and the stiffness matrix that is contributed
% from the other elements (11-16), without the latter being expicitly
% defined under an *element option. The results of both the element-based
% truss model and the matrix-based truss model are compared in terms of the
% von Mises stress that develop at the truss element 17 and are shown to be
% identical.
%
% For more information about this example and *mtx2Matlab* in general,
% please check <http://www.mathworks.com this post> at the *Abaqus2Matlab*
% <http://www.abaqus2matlab.com/ Website>
%

%% Development of the matrix-based truss model in Abaqus
% Degrees of freedom per node of truss model
dofsPerNode=2;

%%
% Obtain the global stiffness matrix using Abaqus2Matlab
[KMAT1,Kout1] = getMatrix('trussFEModel_STIF2.mtx','matrix',...
    'matrix input','global',dofsPerNode);
K = KMAT1{1};

%%
% Matrix size
n=size(K,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag = spdiags(K,0);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Kglob = K+K'-spdiags(Kdiag,0,n,n);

%%
% Local element stiffness matrices of truss model
[KMAT2,Kout2] = getMatrix('trussFEModel_STIF3.mtx','matrix',...
    'matrix input','element by element',dofsPerNode);

%%
% Shift in element numbering (the first element number of the Abaqus model
% is eleshift+1)
eleshift=10;

%%
% Obtain the local stiffness matrix of element 17
K17 = KMAT2{17-eleshift};

%%
% Matrix size
n=size(K17,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag17 = spdiags(K17,0);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Kele17 = K17+K17'-spdiags(Kdiag17,0,n,n);

%%
% Find nonzero elements of the local stiffness matrix of element 17
[r,c]=find(Kele17);

%%
% Subtract the contribution of element 17 from the global stiffness matrix.
Kmod=Kglob;
Kmod(r,c)=Kmod(r,c)-Kele17(r,c);

%%
% Convert the elements of Kmod into matrix input format
[rInp,cInp]=find(Kmod);
node1=ceil(rInp/dofsPerNode);
dof1=rInp-dofsPerNode*(node1-1);
node2=ceil(cInp/dofsPerNode);
dof2=cInp-dofsPerNode*(node2-1);
val=full(Kmod(Kmod~=0));
DataLines=[node1,dof1,node2,dof2,val];

%%
% Copy the Abaqus input file and rename it
copyfile([pwd '\trussFEModel.inp'],[pwd '\trussMatrixModel.inp'])

%%
% Read the contents of the old Abaqus input file
fid=fopen('trussFEModel.inp','r');
str = textscan(fid,'%s','Delimiter','\n');
fclose(fid);

%%
% Open the new Abaqus input file for writing
fid=fopen('trussMatrixModel.inp','w');

%%
% Write lines 1-10 of the old input file to the new input file
for i=1:10
    fprintf(fid,'%s\n',str{1}{i});
end

%%
% Write lines 17-22 of the old input file to the new input file
for i=17:22
    fprintf(fid,'%s\n',str{1}{i});
end

%%
% Print the *MATRIX INPUT option in the new input file followed by proper
% parameters
fprintf(fid,'%s\n','*MATRIX INPUT,NAME=MATRIX1,SCALE FACTOR=1.0');

%%
% Convert the array DataLines from double to string
str1=sprintf('%i,%i,%i,%i,%f\n' ,DataLines');

%%
% Delete the last newline character
str1(end)=[];

%%
% Write the array DataLines in the new input file
fprintf(fid,'%s\n',str1);

%%
% Print the *MATRIX ASSEMBLE option in the new input file followed by
% proper parameters
fprintf(fid,'%s\n','*MATRIX ASSEMBLE,STIFFNESS=MATRIX1');

%%
% Write lines 24-35 of the old input file to the new input file
for i=24:35
    fprintf(fid,'%s\n',str{1}{i});
end

%%
% Close the new Abaqus input file
fclose(fid);

%% Abaqus results
% The new Abaqus input file that is created above needs to be run by Abaqus
% in order to produce the results of the matrix-based truss model. By
% comparing the von Mises stress of the truss element 17 in the
% element-based truss model and in the matrix-based truss model, it is
% shown that the results are identical.

%%
% Show the contents of the input file of the initial (element based) Abaqus
% model
type trussFEModel.inp

%%
% Von Mises stresses in the element-based truss model
%
% <<TrussFE.png>>
%

%%
% Show the contents of the input file of the new (matrix based) Abaqus
% model
type trussMatrixModel.inp

%%
% Von Mises stresses in the matrix-based truss model
%
% <<TrussMat.png>>
%

%%
%  _________________________________________________________________________
%  Abaqus2Matlab - www.abaqus2matlab.com
%  Copyright (c) 2017-2020 by George Papazafeiropoulos
%
%  If using this toolbox for research or industrial purposes, please cite:
%  G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
%  Abaqus2Matlab: a suitable tool for finite element post-processing.
%  Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
%  DOI:10.1016/j.advengsoft.2017.01.006

