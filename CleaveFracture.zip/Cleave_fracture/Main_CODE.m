% %% SCRIPT FILE TO EXTRACT WEIBULL PARAMETERS IN A 3-PARAMETER BEREMIN MODEL
% If using this code for research or industrial purposes, please cite:
% G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
% Abaqus2Matlab: a suitable tool for finite element post-processing.
% Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
% DOI:10.1016/j.advengsoft.2017.01.006

% This code is written by M. Muniz-Calvente, E. Martinez-Paneda
% miguelmunizcalvente@gmail.com

clear
clc
close all
S = mfilename('fullpath');
f = filesep;
ind=strfind(S,f);
S1=S(1:ind(end)-1);
cd(S1)

%% 1st STEP - Run one FEM model
Inp_file='FEM_SIMULATION';

% Run the input file with Abaqus
system(['abaqus job=', Inp_file]);

% Pause Matlab execution to give Abaqus enough time to create the lck file
pause(10)

% If the lck file exists then halt Matlab execution
while exist([Inp_file '.lck'],'file')==2
    pause(0.1)
end

%% 2nd STEP - Postprocess Abaqus results file with Abaqus2Matlab
% Assign all lines of the fil file in an one-row string (after Abaqus
% analysis terminates)

% Obtain the desired output data
out = readFil([Inp_file '.fil'],[1900,101,78,401,12,1991],S1);
% Postprocessing of the output data obtained:
% First set of data (Element connectivity)
[Elem_total, ~]=size(out{1,1});
% Second set of data (stress invariants)
[Nincr, ~]=size(out{1,2});
U_2=out{1,2}(:,3);
% Third set of data (Element Volumme)
Elem=length(out{1,3})/Nincr;% Number of elements
Vi = reshape(out{1,3},[Elem,Nincr]); % Vi(element,increment)
% Fourth set of data (Principal stresses)
SPmaxT = out{1,4}(:, 3);
[rows2, ~]=size(out{1,4});
Int=rows2/(Elem*Nincr); % Number of integration points per element
j=1;
for i=1:Int:(Elem*Nincr*Int)
    SPmaxA(j) = mean(SPmaxT(i:(i+Int-1)));
    j=j+1;
end
SPmax = reshape(SPmaxA',[Elem,Nincr]); % SPmax(element,increment)
% Fifth set of data (stress invariants)
MisesT = out{1,5}(:, 1); %Extract Von Mises stress
j=1;
for i=1:Int:(Elem*Nincr*Int)
    MisesA(j) = mean(MisesT(i:(i+Int-1)));
    j=j+1;
end
Mises = reshape(MisesA',[Elem,Nincr]); % Von Mises stress (element,increment)
% Sixth set of data (J_integral)
J_integral_contours=cell2mat(out{1,6}(:,3:12));
J_integral_contour8=J_integral_contours(:,8);

save('FEM_DATA_RESULTS.mat'); %Save the results extracted in a Matlab file

%% 3rd STEP - Load experimental data
%Read the experimental data (load at failure) from excel file
fileID = fopen('Expt.txt','r');
formatSpec = '%f';
sizeA = [1 Inf];
Data = sort(fscanf(fileID,formatSpec,sizeA));
fclose(fileID);

% Estimate the displacements of the load pin at the failure instant for
% each experiment.

% Delete Jo=0 values from variables (first increments)
positionsJo=find(J_integral_contours(:,8)<1e-4);
J_integral_contours(positionsJo,:)=[];
U_2(positionsJo)=[];
U_exp=interp1(J_integral_contours(:,8),U_2,Data,'spline');
SPmax(:,positionsJo)=[];
Mises(:,positionsJo)=[];
ViTotal=Vi(:,end);

figure
hold on
grid on
plot(U_2,J_integral_contours(:,8),'b-')
plot(U_exp,Data,'*r')
legend ('FEA result','Experimental results')
xlabel 'Displacements[mm]'
ylabel 'J_0 [N/mm]'

%% 4th STEP - To obtain the stresses at each element for each failure case (each Jo value)
%  thera are 2 options to perform this step:
% 1st: to perform 21 FEA with the corresponding displacements previously
% obtained
% 2nd: to used the FEA to interpolate the stresses between 2 load increments
% for each displacement previously obtained

% Option 2 is followed in this example.

% interpolation of stresses
for i=1:Elem
    Smax_exp(i,:)=interp1(J_integral_contours(:,8),SPmax(i,:),Data);
end

% Example of Stress distribution
figure
Q(1)=8;Q(2)=8;
elemType = 'Q8' ;
[XY,XY1,LE,LE1]=ABAQUSmesh2D(Q);
plotNode = 'no' ;
plotMesh2(XY,LE,Smax_exp(:,5),plotNode,elemType)
axis off
colorbar

%% 5th STEP - Fit the values of the Weibull cdf by Beremin approach
% Before starting the iterative fitting procedure we assume a value of SH
% equal to the 75% of the minimum of maximum of SP1 in each experiment
a=1; %number of iteration
Sth(a)=0.75*min(max(Smax_exp));
m(a)=10; % We estipulate an initial value for m
[Nelem, Nloads] = size(Smax_exp);
% We store the probability in p
p=((1:Nloads)'-0.3)./(Nloads+0.4);
error(a)=1;
while (error(a)>0.001) % Iterative fitting procedure
    m0=m(a);Sth0=Sth(a);
    a=a+1;
    Sw=zeros(Nloads,1);
    for i=1:Nloads
        for j=1:Nelem
            if Smax_exp(j,i) > Sth0
                Sw(i,1)=Sw(i,1)+(ViTotal(j))*(Smax_exp(j,i)-Sth0)^m0;
            end
        end
        Sw(i,1)=Sw(i,1).^(1/m0)+Sth0;
    end
    x=(Sw);
    r2 = @(x,y) 1 - norm(y - polyval(polyfit(x,y,1),x)).^2 / norm(y - mean(y)).^2;
    threshObj = @(c) -r2(log(-log(1-p)),log(x-c));
    cHat = fminbnd(threshObj,.5*min(x), .999*min(x));
    poly = polyfit(log(-log(1-p)),log(x-cHat),1);
    paramHat = [exp(poly(2)) 1/poly(1) cHat];
    m(a)=paramHat(2);
    Sth(a)=paramHat(3);
    Su(a)=paramHat(1);
    error(a)=abs((m(a)-m0)/m(a))+abs((Sth(a)-Sth0)/Sth0);
end

m_fit=m(a);
Sth_fit=Sth(a);
Su_fit=Su(a);

%% 6th STEP - Plot the final solutions

% Plot the Cdf obtained
Pf=@(Sw,m,Sth,Su) 1-exp(-((Sw-Sth)./Su).^m);
figure
plot(Sth_fit:0.1:2.5*Sth_fit,Pf(Sth_fit:0.1:2.5*Sth_fit,m_fit,Sth_fit,Su_fit))
xlabel S_w
ylabel P_{fail}
axis([1700 2600 0 1])

% Stimate the probability of failure for the experimental results from the Weibull values obtained
[Nelem, Nloads] = size(SPmax);
Sw=zeros(Nloads,1);
for i=1:Nloads
    for j=1:Nelem
        if SPmax(j,i) > Sth_fit
            Sw(i,1)=Sw(i,1)+(ViTotal(j))*(SPmax(j,i)-Sth_fit)^m_fit;
        end
    end
    Sw(i,1)=Sw(i,1).^(1/m_fit)+Sth_fit;
end

% Plot a comparison between experimental results and estimation of global
% probabilities of failure
[Nelem, Nloads] = size(Smax_exp);
p=((1:Nloads)'-0.3)./(Nloads+0.4);
figure
hold on
plot(J_integral_contours(:,8),Pf((Sw),m_fit ,Sth_fit,Su_fit))
axis([0 350 0 1])
plot(Data,p,'r*')
xlabel J_0
ylabel P_{fail}

% Plot the curve J-integral versus Sw
figure
plot(J_integral_contours(:,8),Sw)
xlabel J_0
ylabel Sw


% Plot a Hazard Map for one of the experiments performed (number 19)
figure
Q(1)=8;Q(2)=8;
elemType = 'Q8' ;
Pf_local=@(Sw,m,Sth,Su,V) 1-exp(-V.*((Sw-Sth)./Su).^m);
local_pf=zeros(1,Nelem);
for element=1:Nelem
    if Smax_exp(element,19)>Sth_fit
        local_pf(1,element)=Pf_local(Smax_exp(element,19),m_fit,Sth_fit,Su_fit,ViTotal(element));
    end
end
[XY,XY1,LE,LE1]=ABAQUSmesh2D(Q);
plotNode = 'no' ;
plotMesh2(XY,LE,(local_pf),plotNode,elemType)
axis off
colorbar











