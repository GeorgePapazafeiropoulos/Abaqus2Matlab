function f = TrussObjfun(x)
% Horizontal length
u=9.144;
% total weight
f = 9.81*2767.990471*x'*u*[1;sqrt(2)];
end