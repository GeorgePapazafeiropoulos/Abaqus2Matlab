% %% SCRIPT FILE TO OPTIMIZE A TRUSS
% If using this code for research or industrial purposes, please cite:
% G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
% Abaqus2Matlab: a suitable tool for finite element post-processing.
% Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
% DOI:10.1016/j.advengsoft.2017.01.006

% This code is written by G. Papazafeiropoulos
% miguelmunizcalvente@gmail.com
clear
clc
close all
S = mfilename('fullpath');
f = filesep;
ind=strfind(S,f);
S1=S(1:ind(end)-1);
cd(S1)

% Declare Abaqus time couonter as global variable (used also in
% TrussConfun.m)
global tABAQUS
% Specify the number of elements of the truss.
NumElements=2;
% Make a starting guess for the solution.
x0 = [0.0037; 0.0049];
% Set the lower and upper limit of the cross section areas of the two
% members of the truss.
AreaMin=0.003650822800775; % P*sqrt(2)/maxstress
AreaMax=0.0225806;
lb=AreaMin*ones(1,NumElements);
ub=AreaMax*ones(1,NumElements);
% Set FunctionTolerance and StepTolerance
options=optimset('fmincon');
options.Display='iter-detailed';
options.TolFun=1e-3;
options.TolCon=1e-3;
% Start timer
tic
tABAQUS=0;
% Perform constrained optimization of the truss
[X,fval,exitflag,output,lambda]=fmincon(@TrussObjfun,x0,[],[],[],[],...
    lb ,ub,'TrussConfun',options)
% Report elapsed times (total, required by Abaqus and required by Matlab
% respectively)
tTOTAL=toc
tABAQUS
tMATLAB=tTOTAL-tABAQUS