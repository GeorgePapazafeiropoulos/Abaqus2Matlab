function [c,ceq] = TrussConfun(x)
% Declare Abaqus timer as global variable
global tABAQUS
% Set the displacement limits of the 2-bar truss
% maximum absolute value of horizontal displacement (m)
Dmaxhor=0.0508;
% maximum absolute value of vertical displacement (m)
Dmaxver=0.0508;
% Construct the Abaqus input file TrussABAQUS.inp
TrussInpFileConstr(x)
% Report time before Abaqus analysis starts
t1=toc;
% Run the input file TrussABAQUS.inp with Abaqus
!abaqus job=TrussABAQUS
% Pause Matlab execution to give Abaqus enough time to create the
% TrussABAQUS.lck file
pause(10)
% If the TrussABAQUS.lck file exists then halt Matlab execution
while exist('TrussABAQUS.lck','file')==2
    pause(0.1)
end
% Report time after Abaqus analysis terminates
t2=toc;
% Add elapsed time to Abaqus time counter
tABAQUS=tABAQUS+t2-t1;
% Obtain the nodal displacements
out2 = readFil('TrussABAQUS.fil',101);
NodalDisplacements=out2{1,1}(:,2:3);
% Delete the files of last Abaqus run to avoid rewriting them
delete('TrussABAQUS.fil');
delete('TrussABAQUS.prt');
delete('TrussABAQUS.com');
delete('TrussABAQUS.sim');
% Calculate the maximum nodal displacements
maxNodDisplX1=max(abs(NodalDisplacements(:,1)));
maxNodDisplY1=max(abs(NodalDisplacements(:,2)));
% Assemble the constraints
c = [maxNodDisplY1-Dmaxver;
    maxNodDisplX1-Dmaxhor];
ceq = [];
end