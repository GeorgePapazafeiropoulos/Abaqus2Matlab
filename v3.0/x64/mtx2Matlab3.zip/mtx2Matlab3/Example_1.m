%% Example_1
% An Abaqus model is developed in terms of the Abaqus input file
% *example.inp*. The input file *example.inp* is provided along with other
% necessary files with this example. The input file *example.inp* must be
% run in Abaqus before running the current script. The model is comprised
% of a 3D beam model discretized in C3D8 elements with a solid section
% associated with a linear elastic material. Along the cross section at the
% one end of the beam a general tangential surface traction is applied
% which is equivalent to a force perpendicular to the beam axis, whereas
% boundary condition of total fixity is applied at the other end of the
% beam. There are 8 steps in the Abaqus input file as follows:
%
% # Static analysis of the beam with the applied load and boundary
% conditions.
% # Frequency analysis of the beam without the applied traction
% # Generation of the global stiffness, mass and load matrices in the
% matrix input format
% # Generation of the global stiffness, mass and load matrices in the
% coordinate format
% # Generation of the global stiffness, mass and load matrices in the
% labels format
% # Generation of the local element stiffness, mass and load matrices in
% the matrix input format
% # Generation of the local element stiffness, mass and load matrices in
% the coordinate format
% # Generation of the local element stiffness, mass and load matrices in
% the labels format
%
% In this example the stiffness and load matrices of the Abaqus model are
% loaded using *mtx2Matlab* and then used for solving the equation of
% static equilibrium of the Abaqus model in Matlab, independently, without
% running an Abaqus analysis. The results of this solution are then
% compared with the results of the Abaqus static analysis specified at the
% step 1 above, in terms of the maximum displacements. The corresponding
% results of the two static analyses are shown to be identical.
%
% For more information about this example and *Abaqus2Matlab* in general,
% please check the *Abaqus2Matlab* <http://www.abaqus2matlab.com/ Website>
%

%% Static analysis in terms of _matrix input_ or _labels_ format
% Degrees of freedom per node of the solid beam model
dofsPerNode=3;

%%
% Obtain the global stiffness and load matrices using Abaqus2Matlab
[KMAT1,Kout1] = getMatrix('example_STIF3.mtx','matrix',...
    'matrix input','global',dofsPerNode);
K = KMAT1{1};
[LMAT1,Lout1] = getMatrix('example_LOAD3.mtx','column vector',...
    'matrix input','global',dofsPerNode);
F = LMAT1{1};

%%
% Problem size
n=size(K,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag = spdiags(K,0);

%%
% Find fixed degrees of freedom
Bfixed=find(Kdiag>9e35);

%%
% Find free degrees of freedom
Bfree=setdiff((1:numel(Kdiag))',Bfixed);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Ksymm = K+K'-spdiags(Kdiag,0,n,n);

%%
% Take the free-free segment of the stiffness matrix
Kff=Ksymm(Bfree,Bfree);

%%
% Take the fixed-free segment of the stiffness matrix
Ksf=Ksymm(Bfixed,Bfree);

%%
% Take the free-free segment of the load matrix. Ensure the compatibility
% of dimensions between the load and the stiffness matrices.
r=find(F);
BfreeL=Bfree(Bfree<=max(r));
Lf=F(BfreeL);
n1=n-max(r);
Lf=[Lf;zeros(n1,1)];

%%
% Solve equilibrium equation (static analysis)
Df=Kff\Lf;
Ls=Ksf*Df;

%%
% Maximum displacement along global X-axis
maxUx=max(abs(Df(1:3:end)))

%%
% Maximum displacement along global Y-axis
maxUy=max(abs(Df(2:3:end)))

%%
% Maximum displacement along global Z-axis
maxUz=max(abs(Df(3:3:end)))

%%
% Maximum reaction force along global X-axis
maxRFx=max(abs(Ls(1:3:end)))

%%
% Maximum reaction force along global Y-axis
maxRFy=max(abs(Ls(2:3:end)))

%%
% Maximum reaction force along global Z-axis
maxRFz=max(abs(Ls(3:3:end)))

%% Static analysis in terms of _coordinate_ format
% Obtain the global stiffness and load matrices using Abaqus2Matlab
[KMAT2,Kout2] = getMatrix('example_STIF4.mtx','matrix',...
    'coordinate','global',dofsPerNode);
K = KMAT2{1};
[LMAT2,Lout2] = getMatrix('example_LOAD4.mtx','column vector',...
    'coordinate','global',dofsPerNode);
F = LMAT2{1};

%%
% Problem size
n=size(K,1);

%%
% Take the main diagonal of stiffness matrix K
Kdiag = spdiags(K,0);

%%
% Find fixed degrees of freedom
Bfixed=find(Kdiag>9e35);

%%
% Find free degrees of freedom
Bfree=setdiff((1:numel(Kdiag))',Bfixed);

%%
% Setup the sparse array in fully populated format (i.e. nonzero elements
% exist both above and below the main diagonal)
Ksymm = K;

%%
% Take the free-free segment of the stiffness matrix
Kff=Ksymm(Bfree,Bfree);

%%
% Take the fixed-free segment of the stiffness matrix
Ksf=Ksymm(Bfixed,Bfree);

%%
% Take the free-free segment of the load matrix. Ensure the compatibility
% of dimensions between the load and the stiffness matrices.
r=find(F);
BfreeL=Bfree(Bfree<=max(r));
Lf=F(BfreeL);
n1=n-max(r);
Lf=[Lf;zeros(n1,1)];

%%
% Solve equilibrium equation (static analysis)
Df=Kff\Lf;
Ls=Ksf*Df;

%%
% Maximum displacement along global X-axis
maxUx=max(abs(Df(1:3:end)))

%%
% Maximum displacement along global Y-axis
maxUy=max(abs(Df(2:3:end)))

%%
% Maximum displacement along global Z-axis
maxUz=max(abs(Df(3:3:end)))

%%
% Maximum reaction force along global X-axis
maxRFx=max(abs(Ls(1:3:end)))

%%
% Maximum reaction force along global Y-axis
maxRFy=max(abs(Ls(2:3:end)))

%%
% Maximum reaction force along global Z-axis
maxRFz=max(abs(Ls(3:3:end)))

%% Abaqus static analysis results
% By comparing the maximum displacement and reaction force of each
% printscreen of Abaqus to the maximum displacements and reaction forces
% that are calculated by Matlab, it is shown that the results are
% identical.

%% 
% Displacement U1
% 
% <<U1.png>>
% 

%% 
% Displacement U2
% 
% <<U2.png>>
% 

%% 
% Displacement U3
% 
% <<U3.png>>
% 

%% 
% Displacement RF1
% 
% <<RF1.png>>
% 

%% 
% Displacement RF2
% 
% <<RF2.png>>
% 

%% 
% Displacement RF3
% 
% <<RF3.png>>
% 

%%
%  _________________________________________________________________________
%  Abaqus2Matlab - www.abaqus2matlab.com
%  Copyright (c) 2017-2020 by George Papazafeiropoulos
%
%  If using this toolbox for research or industrial purposes, please cite:
%  G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
%  Abaqus2Matlab: a suitable tool for finite element post-processing.
%  Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
%  DOI:10.1016/j.advengsoft.2017.01.006

