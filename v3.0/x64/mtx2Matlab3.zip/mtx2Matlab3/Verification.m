%% Verification
% The *mtx2Matlab* component of the *Abaqus2Matlab* software is verified.
% For this purpose, an Abaqus model is developed in terms of the Abaqus
% input file *example.inp*. The input file *example.inp* is provided along
% with other necessary files with this example. The input file
% *example.inp* must be run in Abaqus before running the current script.
% The model is comprised of a 3D beam model discretized in C3D8 elements
% with a solid section associated with a linear elastic material. Along the
% cross section at the one end of the beam a general tangential surface
% traction is applied which is equivalent to a force perpendicular to the
% beam axis, whereas boundary condition of total fixity is applied at the
% other end of the beam. There are 8 steps in the Abaqus input file as
% follows:
%
% # Static analysis of the beam with the applied load and boundary
% conditions.
% # Frequency analysis of the beam without the applied traction
% # Generation of the global stiffness, mass and load matrices in the
% matrix input format
% # Generation of the global stiffness, mass and load matrices in the
% coordinate format
% # Generation of the global stiffness, mass and load matrices in the
% labels format
% # Generation of the local element stiffness, mass and load matrices in
% the matrix input format
% # Generation of the local element stiffness, mass and load matrices in
% the coordinate format
% # Generation of the local element stiffness, mass and load matrices in
% the labels format
%
% In this example it is shown that *mtx2Matlab* can load successfully all
% the types of matrices that are generated in the above steps 3-8 that are
% specified in the Abaqus input file *example.inp*. Maps of the positions
% of the nonzero elements in the stiffness and mass matrices are provided.
%
% For more information about this example and *Abaqus2Matlab* in general,
% please check the *Abaqus2Matlab* <http://www.abaqus2matlab.com/ Website>
%

%% Extract the stiffness matrices
% Global matrix, matrix input format
[KMAT1,Kout1] = getMatrix('example_STIF3.mtx','matrix',...
    'matrix input','global',3);
Kout1

%%
% Plot nonzero elements
figure(1)
spy(KMAT1{1});
title('Global stiffness matrix, matrix input format')

%%
% Global matrix, coordinate format
[KMAT2,Kout2] = getMatrix('example_STIF4.mtx','matrix',...
    'coordinate','global',3);
Kout2

%%
% Plot nonzero elements
figure(2)
spy(KMAT2{1});
title('Global stiffness matrix, coordinate format')

%%
% Global matrix, labels format
[KMAT3,Kout3] = getMatrix('example_STIF5.mtx','matrix',...
    'labels','global',3);
Kout3

%%
% Plot nonzero elements
figure(3)
spy(KMAT3{1});
title('Global stiffness matrix, labels format')

%%
% Local element matrices, matrix input format
[KMAT4,Kout4] = getMatrix('example_STIF6.mtx','matrix',...
    'matrix input','element by element',3);
Kout4

%%
% Plot nonzero elements
figure(4)
spy(KMAT4{1});
title('Local stiffness matrix of 1st element, matrix input format')

%%
% Local element matrices, coordinate format
[KMAT5,Kout5] = getMatrix('example_STIF7.mtx','matrix',...
    'coordinate','element by element',3);
Kout5

%%
% Plot nonzero elements
figure(5)
spy(KMAT5{1});
title('Local stiffness matrix of 1st element, coordinate format')

%%
% Local element matrices, labels format
[KMAT6,Kout6] = getMatrix('example_STIF8.mtx','matrix',...
    'labels','element by element',3);
Kout6

%%
% Plot nonzero elements
figure(6)
spy(KMAT6{1});
title('Local stiffness matrix of 1st element, labels format')

%% Extract the mass matrices
% Global matrix, matrix input format
[MMAT1,Mout1] = getMatrix('example_MASS3.mtx','matrix',...
    'matrix input','global',3);
Mout1

%%
% Plot nonzero elements
figure(7)
spy(MMAT1{1});
title('Global mass matrix, matrix input format')

%%
% Global matrix, coordinate format
[MMAT2,Mout2] = getMatrix('example_MASS4.mtx','matrix',...
    'coordinate','global',3);
Mout2

%%
% Plot nonzero elements
figure(8)
spy(MMAT2{1});
title('Global mass matrix, coordinate format')

%%
% Global matrix, labels format
[MMAT3,Mout3] = getMatrix('example_MASS5.mtx','matrix',...
    'labels','global',3);
Mout3

%%
% Plot nonzero elements
figure(9)
spy(MMAT3{1});
title('Global mass matrix, labels format')

%%
% Local element matrices, matrix input format
[MMAT4,Mout4] = getMatrix('example_MASS6.mtx','matrix',...
    'matrix input','element by element',3);
Mout4

%%
% Plot nonzero elements
figure(10)
spy(MMAT4{1});
title('Local mass matrix of 1st element, matrix input format')

%%
% Local element matrices, coordinate format
[MMAT5,Mout5] = getMatrix('example_MASS7.mtx','matrix',...
    'coordinate','element by element',3);
Mout5

%%
% Plot nonzero elements
figure(11)
spy(MMAT5{1});
title('Local mass matrix of 1st element, coordinate format')

%%
% Local element matrices, labels format
[MMAT6,Mout6] = getMatrix('example_MASS8.mtx','matrix',...
    'labels','element by element',3);
Mout6

%%
% Plot nonzero elements
figure(12)
spy(MMAT6{1});
title('Local mass matrix of 1st element, labels format')

%% Extract the load matrices
% Global matrix, matrix input format
[LMAT1,Lout1] = getMatrix('example_LOAD3.mtx','column vector',...
    'matrix input','global',3);
Lout1

%%
% Global matrix, coordinate format
[LMAT2,Lout2] = getMatrix('example_LOAD4.mtx','column vector',...
    'coordinate','global',3);
Lout2

%%
% Global matrix, labels format
[LMAT3,Lout3] = getMatrix('example_LOAD5.mtx','column vector',...
    'labels','global',3);
Lout3

%%
% Local element matrices, matrix input format
[LMAT4,Lout4] = getMatrix('example_LOAD6.mtx','column vector',...
    'matrix input','element by element',3);
Lout4

%%
% Local element matrices, coordinate format
[LMAT5,Lout5] = getMatrix('example_LOAD7.mtx','column vector',...
    'coordinate','element by element',3);
Lout5

%%
% Local element matrices, labels format
[LMAT6,Lout6] = getMatrix('example_LOAD8.mtx','column vector',...
    'labels','element by element',3);
Lout6

%%
%  _________________________________________________________________________
%  Abaqus2Matlab - www.abaqus2matlab.com
%  Copyright (c) 2017-2020 by George Papazafeiropoulos
%
%  If using this toolbox for research or industrial purposes, please cite:
%  G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
%  Abaqus2Matlab: a suitable tool for finite element post-processing.
%  Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
%  DOI:10.1016/j.advengsoft.2017.01.006


