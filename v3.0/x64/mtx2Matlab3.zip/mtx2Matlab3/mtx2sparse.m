%
% Convert data scanned from an Abaqus *.mtx file to sparse array format
%
% Syntax
%     [#row#,#col#,#val#,#out#] = mtx2sparse(#C#,#mat#,#fmt#,#assembly#,...
%         #dofsPerNode#)
%
% Description
%     This function calculates the row, column and nonzero element vectors
%     required for the generation of a sparse matrix in MATLAB, from the
%     data that are scanned from an Abaqus *.mtx file and stored into a
%     double array. Initially, the *.mtx file must be scanned by the
%     function mtxScan.m, which gives a double array containing the data of
%     the *.mtx file. After some proper reshaping (if necessary) the double
%     array is processed by the function mtx2sparse.m (this function) and
%     gives the necessary row, column and nonzero value vectors that are
%     used for the definition of a Matlab sparse array equivalent to the
%     corresponding array of the Abaqus model that generated the *.mtx
%     file, which can be easily manipulated in Matlab.
%     Based on the output of this function, the sparse global array
%     #M_glob# is obtained in Matlab as follows:
%
%         #M_glob#=sparse(#row#,#col#,#val#);
%
%     and the sparse local array of the #j#th element #M_ele_j# is obtained
%     in Matlab as follows:
%
%         #m#=nnz(#row#(:,#j#));
%         #M_ele_j#=sparse(#row#(1:#m#,#j#),#col#(1:#m#,#j#),...
%             #val#(1:#m#,#j#))
%
% Input parameters
%     REQUIRED:
%     #C# [double(:inf x :6)] is a double array containing the data of the
%         Abaqus *.mtx file. Depending on the format of the *.mtx file, it
%         must be properly reshaped before processed by this function.
%     #mat# [logical(1 x 1)] is a scalar boolean which specifies whether a
%         matrix or a column vector is processed from the Abaqus *.mtx
%         file. It can take the following values:
%         true: a stiffness, mass, viscous damping, or structural
%         damping matrix is generated
%         false: a load column vector is generated
%     #fmt# [double(1 x 1)] is a scalar depending on the value of the
%         FORMAT parameter of the *MATRIX OUTPUT option in the Abaqus
%         matrix generation step. If *MATRIX OUTPUT,FORMAT=MATRIX INPUT, or
%         *MATRIX OUTPUT,FORMAT=LABELS is used, then #fmt# should be set
%         equal to 1. If *MATRIX OUTPUT,FORMAT=COORDINATE is used, then
%         #fmt# should be set equal to 2. If #fmt# has any value other than
%         1 or 2, #C# is not processed and an error is issued.
%     #assembly# [double(1 x 1)] is a scalar depending on whether *MATRIX
%         GENERATE contains the parameter ELEMENT BY ELEMENT or not. If
%         *MATRIX GENERATE contains the parameter ELEMENT BY ELEMENT, then
%         #assembly# should be set equal to 2. If not, it should be set
%         equal to 1. If #assembly# has any value other than 1 or 2, #C# is
%         not processed and an error is issued.
%     #dofsPerNode# [double(1 x 1)] is a scalar equal to the number of
%         degrees of freedom that are associated with each node of the
%         Abaqus model being analyzed. If there are nodes in the same
%         Abaqus model which have different number of degrees of freedom,
%         then #dofsPerNode# is equal to the maximum number of degrees of
%         freedom between these nodes.
%
% Output parameters
%     #row# [double(:inf x :#n#)] contains the row IDs of the nonzero
%         elements of the matrix data that is included in the Abaqus *.mtx
%         file. It is a column vector if #assembly#=1 is specified (global
%         stiffness/mass/damping/load matrix is extracted), and an array if
%         #assembly#=2 is specified. In the latter case (#assembly#=2) the
%         number of columns of #row# is equal to the number of elements #n#
%         that are included in the Abaqus *.mtx file.
%     #col# [double(:inf x :#n#)] contains the column IDs of the nonzero
%         elements of the matrix data that is included in the Abaqus *.mtx
%         file. It is a column vector if #assembly#=1 is specified (global
%         stiffness/mass/damping/load matrix is extracted), and an array if
%         #assembly#=2 is specified. In the latter case (#assembly#=2) the
%         number of columns of #col# is equal to the number of elements #n#
%         that are included in the Abaqus *.mtx file. If the *.mtx file
%         contains a load matrix, then #col# is an array with ones in the
%         positions of the nonzero values of the load matrix.
%     #val# [double(:inf x :#n#)] contains the nonzero values of the sparse
%         array, corresponding to the #row# and #col# values. The following
%         identity holds for the #i#th element of a global matrix #M_glob#:
%
%             #M_glob#(#row#(#i#),#col#(#i#))=#val#(#i#)
%
%         and the following identity holds for the #i#th element of the
%         local matrix of the #j#th element #M_ele_j#:
%
%             #M_ele_j#(#row#(#i#,#j#),#col#(#i#,#j#))=#val#(#i#,#j#)
%
%     #out# [struct(1 x 1)] contains output for the information of the
%         user, in the following format:
%         #out#.MATRIXTYPE
%         #out#.FORMAT
%         #out#.ASSEMBLY
%         If a stiffness/mass/damping matrix is processed:
%             #out#.MATRIXTYPE='STIFFNESS/MASS/DAMPING'
%         If a load column vector is processed:
%             #out#.MATRIXTYPE='LOAD'.
%         If #fmt#=1:
%             #out#.FORMAT='MATRIX INPUT/LABELS'
%         If #fmt#=2:
%             #out#.FORMAT='COORDINATE'
%         If #assembly#=1:
%             #out#.ASSEMBLY='GLOBAL'
%         If #assembly#=2:
%             #out#.ASSEMBLY='ELEMENT BY ELEMENT'
%
% _________________________________________________________________________
% Abaqus2Matlab - www.abaqus2matlab.com
% Copyright (c) 2017-2020 by George Papazafeiropoulos
%
% If using this toolbox for research or industrial purposes, please cite:
% G. Papazafeiropoulos, M. Muniz-Calvente, E. Martinez-Paneda.
% Abaqus2Matlab: a suitable tool for finite element post-processing.
% Advances in Engineering Software. Vol 105. March 2017. Pages 9-16. (2017)
% DOI:10.1016/j.advengsoft.2017.01.006
%
% Built-in function

